<?php
/**
 * Created by PhpStorm.
 * User: Yuri
 * Date: 17/03/2015
 * Time: 08:42 PM
 */

class Multimedia  extends BaseController{

} 